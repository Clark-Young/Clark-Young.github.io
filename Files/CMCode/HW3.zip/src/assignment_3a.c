#include<stdio.h>
#include<math.h>
double MAX(double a[],int size) {
	double max=0;
	int i=0;
	max=a[0];
	for(i=1; i<size; i++) {
		if(a[i]>max){
			max=a[i];
		}
	}
	return max;
}

int main () {
	double A[5][5]= {{1.0/9,1.0/8,1.0/7,1.0/6,1.0/5},{1.0/8,1.0/7,1.0/6,1.0/5,1.0/4},{1.0/7,1.0/6,1.0/5,1.0/4,1.0/3},{1.0/6,1.0/5,1.0/4,1.0/3,1.0/2},{1.0/5,1.0/4,1.0/3,1.0/2,1}};
	double L[5][5],U[5][5];
	double X[5]= {0,0,0,0,0};
	double copy_Y[5]= {0,0,0,0,0};
	double Y[5]= {1,1,1,1,1};
	double C[5][5];
	int i=0,j=0,k=0,r=0,l=0;
	double sum=0,lambda[99];
	for(i=0; i<5; i++) {
		for(j=0; j<5; j++) {
			L[i][j]=0;
			U[i][j]=0;
			C[i][j]=0;
			if(i==j) {
				L[i][j]=1;
			}
		}
	}

	for(k=0; k<5; k++) {
		for(j=k; j<5; j++) {
			if(k==0) {
				U[k][j]=A[k][j];
			}
			sum=0;
			for(r=0; r<k; r++) {
				sum+=L[k][r]*U[r][j];
			}
			U[k][j]=A[k][j]-sum;
		}
		for(i=k+1; i<5; i++) {
			if(k==1) {
				L[i][k]=A[i][k]/U[k][k];
			}
			sum=0;
			for(r=0; r<k; r++) {
				sum+=L[i][r]*U[r][k];
			}
			L[i][k]=(A[i][k]-sum)/U[k][k];

		}
	}
	printf("LU�ֽ�õ���L����Ϊ��\n"); 
	for(i=0; i<5; i++) {
		for(j=0; j<5; j++) {
			printf("%f\t",L[i][j]);
		}
		printf("\n");
	}
	printf("LU�ֽ�õ���U����Ϊ��\n");
		for(i=0; i<5; i++) {
		for(j=0; j<5; j++) {
			printf("%f\t",U[i][j]);
		}
		printf("\n");
	}
//	for(i=0;i<5;i++){
//		for(j=0;j<5;j++){
//			for(k=0;k<5;k++){
//				C[i][j]+=L_1[i][k]*U_1[k][j];
//			}
//		}
//	}
//		for(i=0; i<5; i++) {
//		for(j=0; j<5; j++) {
//			printf("%f\t",C[i][j]);
//		}
//		printf("\n");
//	}
	lambda[0]=0;
	int count =1 ;
		for(k=0; k<5; k++) {
		copy_Y[k]=Y[k];
	}
	for(k=0; k<5; k++) {
		for(j=k+1; j<5; j++) {
			Y[j]=Y[j]-L[j][k]/L[k][k]*Y[k];
		}
	}
	for(k=4; k>=0; k--) {
		for(l=k-1; l>=0; l--) {
			Y[l]=Y[l]-U[l][k]/U[k][k]*Y[k];
		}
	}
	for(k=0; k<5; k++) {
		Y[k]=Y[k]/U[k][k];
	}
	for(k=0; k<5; k++) {
		X[k]=Y[k];
	}
	lambda[count]=MAX(copy_Y,5)/MAX(X,5);
		printf("��%d�ε���������ֵΪ��%.8f ��������Ϊ(",count,lambda[count]);
	for(k=0; k<5; k++) {
		Y[k]=X[k]/MAX(X,5);
	}
		for(i=0; i<5; i++) {
		if(i!=4) {
		printf("%f,",Y[i]);
		}else {
		printf("%f",Y[i]);
		}
	}
	printf(")\n");
	count++;
	while(fabs(lambda[count-1]-lambda[count-2])>0.000000000001){
	for(k=0; k<5; k++) {
		copy_Y[k]=Y[k];
	}
	for(k=0; k<5; k++) {
		for(j=k+1; j<5; j++) {
			Y[j]=Y[j]-L[j][k]/L[k][k]*Y[k];
		}
	}
	for(k=4; k>=0; k--) {
		for(l=k-1; l>=0; l--) {
			Y[l]=Y[l]-U[l][k]/U[k][k]*Y[k];
		}
	}
	for(k=0; k<5; k++) {
		Y[k]=Y[k]/U[k][k];
	}
	for(k=0; k<5; k++) {
		X[k]=Y[k];
	}
	lambda[count]=MAX(copy_Y,5)/MAX(X,5);
		printf("��%d�ε���������ֵΪ��%.8f ��������Ϊ(",count,lambda[count]);
	for(k=0; k<5; k++) {
		Y[k]=X[k]/MAX(X,5);
	}
		for(i=0; i<5; i++) {
		if(i!=4) {
		printf("%f,",Y[i]);
		}else {
		printf("%f",Y[i]);
		}
	}
	printf(")\n");
	count++;
	}
	printf("�����������ֵ��С����������Ϊ��");
	printf("(");
		for(i=0; i<5; i++) {
		if(i!=4) {
		printf("%f,",Y[i]);
		}else {
		printf("%f",Y[i]);
		}
	}
	printf(")\n");
	printf("����������С����ֵΪ %.8f",lambda[count-1]);
	return 0;
}
