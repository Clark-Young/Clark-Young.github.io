#include <stdio.h>
#include <math.h>
int p = 0, m = 0, t = 0;
int M = 1;
double varepsilon;
double f_t(double a)
{
    return 1 / a;
}
double fun_x(double a)
{
    return sin(a) / (sqrt(a) + 1);
}
double fun_y(double a)
{
    return log(a + 1) / (a + 1);
}
double sum_a(int k, double h_k, double a, double (*p)(double a))
{
    double sum = 0;
    for (int i = 0; i < pow(2, k - 1); i++)
    {
        sum += p(a + (2 * i + 1) * h_k);
    }
    return sum * h_k * 2;
}
double Romberg(double a, double b, int M, double (*func)(double a), double varepsilon)
{
    t++;
    int k = 0;
    int j = 0;
    double h = b - a;
    double h_k = 0;
    double r1[M], r2[M];
    r1[0] = (func(a) + func(b)) / 2 * h;
    for (k = 1; k < M; k++)
    {
        h_k = h / pow(2, k);
        r2[0] = 0.5 * (r1[0] + sum_a(k, h_k, a, func));
        for (j = 1; j < k + 1; j++)
        {
            r2[j] = r2[j - 1] + (r2[j - 1] - r1[j - 1]) / (pow(4, j) - 1);
        }

        if (fabs(r2[k] - r1[k - 1]) < 0.001 * varepsilon)
        {
            p++;
            return r2[k];
        }
        for (j = 0; j < k + 1; j++)
        {
            r1[j] = r2[j];
        }
    }
    m++;
    return r2[M - 1];
}
double v_x(double a)
{
    return Romberg(0, a, M, fun_x, varepsilon);
}
double v_y(double b)
{
    return Romberg(0, b, M, fun_y, varepsilon);
}

int main()
{
    while (M != 0)
    {
        printf("请输入最大迭代次数，收敛性判据，结束迭代输入0 0：");
        scanf("%d %lf", &M, &varepsilon);
        if (M == 0)
        {
            break;
        }
        double part_x[100], part_y[100];
        double x_t[100] = {0}, y_t[100] = {0};

        for (int i = 0; i < 100; i++)
        {
            part_x[i] = Romberg(0.1 * i, 0.1 * (i + 1.0), M, v_x, varepsilon);
            part_y[i] = Romberg(0.1 * i, 0.1 * (i + 1.0), M, v_y, varepsilon);
        }
        for (int i = 0; i < 100; i++)
        {
            for (int j = 0; j < i + 1; j++)
            {
                x_t[i] += part_x[j];
                y_t[i] += part_y[j];
            }
            printf("t=%.1f时的位置为(%f,%f),", 0.1 *(i + 1), x_t[i], y_t[i]);
                if ((i + 1) % 4 == 0)
                {
                    printf("\n");
                }
        }

        printf("达到要求精度的比例为%d/%d=%.2f%%\n\n", p, t, (100.0 * p) / t);
        p = 0;
        t = 0;
        m = 0;
    }

    return 0;
}
