#include <iostream>
#include <stdlib.h>
#include <complex>
#include <vector>
#include <stdio.h>
#include <time.h>
#include <fstream>
#define PI 3.1415926535897932

using namespace std;

double func_1(double a)
{
    double ret;
    ret = 0.7 * sin(4 * a * PI) + sin(10 * PI * a);
    return ret;
}

double func_2(double a)
{
    srand(time(0));
    return func_1(a) + 0.3 * rand()/RAND_MAX;
}

void FFT(double f[], int n, complex<double> g[])
{
    int k;
    if (n == 1)
    {
        g[0] = f[0] + 0i;
    }
    else
    {
        complex<double> i(0, 1);
        complex<double> Omega(1, 0);
        complex<double> g_1[n / 2], g_2[n / 2];
        double funct_1[n / 2], funct_2[n / 2];
        
        complex<double> Omega_n = exp(-2.0 / n * PI * i);
        for (k = 0; k < n / 2; k++)
        {
            funct_1[k] = f[2 * k];
            funct_2[k] = f[2 * k + 1];
        }
        FFT(funct_1, n / 2, g_1);
        FFT(funct_2, n / 2, g_2);
        for (k = 0; k < n / 2; k++)
        {
            g[k] = 0.5 * (g_1[k] + Omega * g_2[k]);

            g[k + n / 2] = 0.5 * (g_1[k] - Omega * g_2[k]);
            Omega = Omega * Omega_n;
        }
    }
}
void IFFT(complex<double> f[], int n, complex<double> g[])
{
    int k = 0;
    if (n == 1)
    {
        f[0] = g[0];
    }
    else
    {
        complex<double> i(0, 1);
        complex<double> Omega(1, 0);
        complex<double> Omega_n = exp(2.0 / n * PI * i);
        complex<double> gunct_1[n / 2], gunct_2[n / 2];
        complex<double> f_1[n / 2], f_2[n / 2];
        for (k = 0; k < n / 2; k++)
        {
            gunct_1[k] = g[2 * k];
            gunct_2[k] = g[2 * k + 1];
        }
        IFFT(f_1, n / 2, gunct_1);
        IFFT(f_2, n / 2, gunct_2);
        for (k = 0; k < n / 2; k++)
        {
            f[k] = f_1[k] + Omega * f_2[k];
            f[k + n / 2] = f_1[k] - Omega * f_2[k];
            Omega = Omega * Omega_n;
        }
    }
}
int main()
{
    double funct_25_af[128];
    complex<double> funct_25[128];
    complex<double> zi(0, 1);
    complex<double> g_1[128],g_2[128],g_s[16];
    double f_1_simple[4], f_1[128], f_2[128];
    complex<double> f_n_1_simple[16], f_n_1[128], f_n_2[128];
    double f1_af[128],f1s_af[16],f2_af[128];
    double g_1r[128],g_2r[128],g_sr[128];
    double g_1i[128],g_2i[128],g_si[128];
    int n = 128;
    int j = 0;
    cout<<"Fourier�任ǰ��f1,n=16Ϊ"<<endl;
    for (j = 0; j < 16; j++)
    {
        f_1_simple[j] = func_1(j / 16.0);
        cout<<f_1_simple[j]<<",";
        if((j+1)%8==0){
            cout<<endl;
        }
    }
    cout<<endl;
    cout<<"Fourier�任ǰ��f1,n=128Ϊ"<<endl;
    for (j = 0; j < 128; j++)
    {
        f_1[j] = func_1(j / 128.0);
        cout<<f_1[j]<<",";
        if((j+1)%8==0){
            cout<<endl;
        }
    }
    cout<<endl;
    cout<<"Fourier�任ǰ��f2,n=16Ϊ"<<endl;

        for (j = 0; j < 128; j++)
    {
        f_2[j] = func_2(j / 128.0);
        cout<<f_2[j]<<",";
        if((j+1)%16==0){
            cout<<endl;
        }
        
    }
    cout<<endl;
    FFT(f_1, 128, g_1);
    for(j=0;j<128;j++){
        g_1r[j]=g_1[j].real();
        g_1i[j]=g_1[j].imag();
    }
    IFFT(f_n_1,128,g_1);
    for(j=0;j<128;j++){
        f1_af[j]=f_n_1[j].real();
    }
    FFT(f_2, 128, g_2);
    for(j=0;j<128;j++){
        g_2r[j]=g_2[j].real();
        g_2i[j]=g_2[j].imag();
    }
    IFFT(f_n_2,128,g_2);
    for(j=0;j<128;j++){
        f2_af[j]=f_n_2[j].real();
    }
    for(j=32;j<128;j++){
        g_2[j]= 0i;
    }
    IFFT(funct_25,128,g_2);
    for(j=0;j<128;j++){
        funct_25_af[j]=funct_25[j].real();
    }
    FFT(f_1_simple,16,g_s);
    for(j=0;j<16;j++){
        g_sr[j]=g_s[j].real();
        g_si[j]=g_s[j].imag();
    }
    IFFT(f_n_1_simple,16,g_s);
    for(j=0;j<16;j++){
        f1s_af[j]=f_n_1_simple[j].real();
    }
    printf("f_1��n=2^4�£�����Ҷ�任��õ���g��ʵ��Ϊ\n");
    for(j=0;j<16;j++){
        cout<<g_sr[j]<<", ";
        if((j+1)%16==0){
            cout<<endl;
        }
    }
    printf("\n");
    printf("f_1��n=2^4�£�����Ҷ�任��õ���g���鲿Ϊ\n");
    for(j=0;j<16;j++){
        cout<<g_si[j]<<", ";
        if((j+1)%16==0){
            cout<<endl;
        }
    }
    printf("\n");
    printf("f_1��n=2^4�£�����Ҷ�任����任��Ϊ\n");
    for(j=0;j<16;j++){
        cout<<f1s_af[j]<<",";
    if((j+1)%8==0){
            cout<<endl;
        }
    }
    printf("\n");
    printf("f_1��n=2^7�£�����Ҷ�任��õ���g��ʵ��Ϊ\n");
    for(j=0;j<128;j++){
        cout<<g_1r[j]<<", ";
        if((j+1)%16==0){
            cout<<endl;
        }
    }
    printf("\n");
    printf("f_1��n=2^7�£�����Ҷ�任��õ���g���鲿Ϊ\n");
    for(j=0;j<128;j++){
        cout<<g_1i[j]<<", ";
        if((j+1)%16==0){
            cout<<endl;
        }
    }
    printf("\n");
    printf("f_1��n=2^7�£�����Ҷ�任����任��Ϊ\n");
    for(j=0;j<128;j++){
        cout<<f1_af[j]<<",";
    if((j+1)%8==0){
            cout<<endl;
        }
    }
    printf("\n");
    printf("f_2��n=2^7�£�����Ҷ�任��õ���g��ʵ��Ϊ\n");
    for(j=0;j<128;j++){
        cout<<g_2r[j]<<", ";
        if((j+1)%16==0){
            cout<<endl;
        }
    }
    printf("\n");
    printf("f_2��n=2^7�£�����Ҷ�任��õ���g���鲿Ϊ\n");
    for(j=0;j<128;j++){
        cout<<g_2i[j]<<", ";
        if((j+1)%16==0){
            cout<<endl;
        }
    }
    printf("\n");
    printf("f_2��n=2^7�£�����Ҷ�任����任��Ϊ\n");
    for(j=0;j<128;j++){
        cout<<f2_af[j]<<",";
    if((j+1)%8==0){
            cout<<endl;
        }
    }
    printf("\n");
    cout<<"���ٸ���Ҷ�任ȡƵ����ǰ25%��ϵ�����п��ٸ���Ҷ�任����任�Ľ��Ϊ��"<<endl;
    for(j=0;j<128;j++){
        cout<<funct_25_af[j]<<",";
        if((j+1)%8==0){
            cout<<endl;
        }
    }
    return 0;
}
