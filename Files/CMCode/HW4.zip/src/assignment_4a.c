#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<math.h>

double sum_ainj(double a[][4],int dimension) {
	int i,j;
	double sum_sumainj=0;
	for(i=0; i<dimension; i++) {
		for(j=0; j<dimension; j++) {
			if(j!=i) {
				sum_sumainj+=a[i][j]*a[i][j];
			}
		}
	}
	return sqrt(sum_sumainj);
}
double vec_multiply(double a[],double b[],int c){
	int i=0;
	double sum=0;
	for(i=0;i<c;i++){
		sum+=a[i]*b[i];
	}
	return sum;
}

void Bubble_sort(double arr[], double V[4][4], int size) {
	int j,i,k;
	double tem;
	for (i = 0; i < size-1; i ++) {
		int count = 0;
		for (j = 0; j < size-1 - i; j++) {
			if (arr[j] < arr[j+1]) {
				tem = arr[j];
				arr[j] = arr[j+1];
				arr[j+1] = tem;
				count = 1;
				for(k=0;k<4;k++){
					tem=V[k][j];
					V[k][j]=V[k][j+1];
					V[k][j+1]=tem;
				}
			}
		}
		if (count == 0)
			break;
	}

}

double solve_rb(double a) {
	double t_1=0,t_2=0;
	t_1=-a+sqrt(a*a+1);
	t_2=-a-sqrt(a*a+1);
	if(fabs(t_1)>fabs(t_2)) {
		return t_2;
	} else {
		return t_1;
	}
}

int main() {
	int count =0;
	srand((unsigned int)time(NULL));
	double ast[99];
	double a,b;
	double s=0;
	long double t;
	double c,d;
	int i,j,k,p=0,q=1;
	double temp;
	double U[4][4],copy_U[4][4],record_s[4][4],record[4][4];
	double A[4][3]={0.592449,0.754611,0.563630,
	0.376790,0.513549,0.624150,
	0.559907,0.837171,0.537590,
	0.613541,0.673488,0.053709};
	double A_T[3][4]={0.592449,0.376790,0.559907,0.613541,
	0.754611,0.513549,0.837171,0.673488,
	0.563630,0.624150,0.537590,0.053709,
	};
	double X[4][4];
	double Ortho_V[3][3]={0,0,0,0,0,0,0,0,0};
	double V_T[3][3]={0,0,0,0,0,0,0,0,0};
	double kv[4]={0,0,0,0};
	FILE *astringency=NULL;
	astringency=fopen("astringency.txt","w");
	double Q[4][4],copy_Q[4][4];
	double copy[4][4];
	double lambda[4];
	double Sigma[4][4];
	double V[4][4];
	for(i=0; i<4; i++) { // ���󸳳�ֵ
		for(j=0; j<4; j++) {
			X[i][j]=0;
			U[i][j]=0;
			Q[i][j]=0;
			Sigma[i][j]=0;
		}
	}
	for(i=0; i<4; i++) {
		U[i][i]=1;
		Q[i][i]=1;
	}
	// for(i=0; i<4; i++) {//�����������
	// 	for(j=0; j<3; j++) {
	// 		a=rand();
	// 		b=rand();
	// 		A[i][j]=a/(a+b);
	// 		A_T[j][i]=a/(a+b);
	// 	}
	// }
	for(i=0; i<4; i++) {//����X����
		for(j=0; j<4; j++) {
			for(k=0; k<3; k++) {
				X[i][j]=X[i][j]+A[i][k]*A_T[k][j];
			}
		}
	}
	for(i=0; i<4; i++) {
		for(j=0; j<4; j++) {
			record[i][j]=X[i][j];
			record_s[i][j]=X[i][j];
		}
	}
	// printf("��������ľ���AΪ��\n");
	// for(i=0; i<4; i++) {
	// 	for(j=0; j<3; j++) {
	// 		printf("%f,",A[i][j]);
	// 	}
	// 	printf("\n");
	// }
	printf("��������ľ���XΪ��\n");
	for(i=0; i<4; i++) {
		for(j=0; j<4; j++) {
			printf("%f\t",X[i][j]);
		}
		printf("\n");
	}
	while(sum_ainj(X,4)>0.000000001) {
		count=count+1;
		temp=X[0][1];
		p=0;
		q=1;
		for(i=0; i<4; i++) {
			for(j=i+1; j<4; j++) {
				if(i!=j) {
					if(fabs(X[i][j])>fabs(temp)) {
						p=i;
						q=j;
						temp=X[i][j];
					}
				}
			}
		}

		s=(X[q][q]-X[p][p])/(2*X[p][q]);

		if(s==0) {
			t=1;
		} else {
			t=solve_rb(s);
		}

		c=1/sqrt(1+t*t);
		d=t/sqrt(1+t*t);
		for(i=0; i<4; i++) {
			for(j=0; j<4; j++) {
				copy[i][j]=X[i][j];
				copy_U[i][j]=U[i][j];
			}
		}
		Q[p][p]=c,Q[p][q]=d,Q[q][p]=-d,Q[p][p]=c;
		for(i=0; i<4; i++) {
			for(j=0; j<4; j++) {
				U[i][j]=0;
			}
		}
		for(i=0; i<4; i++) {
			for(j=0; j<4; j++) {
				for(k=0; k<4; k++) {
					U[i][j]=U[i][j]+copy_U[i][k]*Q[k][j];
				}
			}
		}
		for(i=0; i<4; i++) {
			for(j=0; j<4; j++) {
				if(i==j) {
					Q[i][j]=1;
				} else {
					Q[i][j]=0;
				}
			}
		}
		for(i=0; i<4; i++) {
			if(i!=p&&i!=q) {
				X[i][p]=X[p][i]=c*copy[p][i]-d*copy[q][i];
				X[i][q]=X[q][i]=c*copy[q][i]+d*copy[p][i];
			}
		}
		X[p][p]=copy[p][p]-t*copy[p][q];
		X[q][q]=copy[q][q]+t*copy[p][q];
		X[p][q]=X[q][p]=0;
		ast[count-1]=sum_ainj(X,4);
		fprintf(astringency,"%d\t %.12f\n",count,ast[count-1]);
		if(count>=98) {
			break;
		}
	}
	// printf("���������Լ����Ӧ�ķǶԽ�Ԫƽ����Ϊ��\n");
	// for(i=0;i<count;i++){
	// 	printf("%d",i+1);
	// 	if(i!= count-1){
	// 		printf("\t");
	// 	}else{
	// 		printf("\n");
	// 	}
	// 	if((i+1)%4==0&&i!=count-1){
	// 		printf("\n");
	// 	}
	// }
	// for(i=0;i<count;i++){
	// 	printf("%.12f",ast[i]);
	// 	if(i !=count-1){
	// 		printf("\t");
	// 	}else{
	// 		printf("\n");
	// 	}
	// 		if((i+1)%4==0&&i!=count-1){
	// 		printf("\n");
	// 	}
	// }
	for(i=0; i<4; i++) {
		if(fabs(X[i][i]>0.000000000001)){
			lambda[i]=X[i][i];
		}else{
			lambda[i]=0;
		}
	}
	// printf("����ֵΪ��");
	// for(i=0; i<4; i++) {
	// 	printf("%.16f\t",lambda[i]);
	// }
	printf("\n");
	Bubble_sort(lambda,U,4);
	printf("����������ֵΪ��");	
	for(i=0; i<4; i++) {
		printf("%.16f\t",lambda[i]);

	}
	printf("\n");	
	printf("��֮��Ӧ����������Ϊ��\n");	
	for(i=0; i<4; i++) {
		for(j=0; j<4; j++) {
			printf("%f\t",U[i][j]);
		}
		printf("\n");
	}
	printf("\n");
	for(i=0;i<4;i++){
		Sigma[i][i]=sqrt(lambda[i]);
	}
	printf("����Ϊ��\n");
	for(i=0;i<4;i++){
		for(j=0;j<4;j++){
			printf("%f\t",Sigma[i][j]);
		}
		printf("\n");
	}
	i=0;
	while(lambda[i]!=0&&i<4){
		for(j=0;j<3;j++){
			for(k=0;k<4;k++){
				V[j][i]=V[j][i]+A[k][j]*U[k][i];
			}
			V[j][i]=V[j][i]/Sigma[i][i];
		}
		i++;
	}
	V[3][3]=1;
	// printf("����õ���V�������£�\n");
	// for(i=0;i<4;i++){
	// 	for(j=0;j<4;j++){
	// 		printf("%f\t",V[i][j]);
	// 	}
	// 	printf("\n");
	// }
	for(i=0;i<3;i++){
		for(j=0;j<3;j++){
			V_T[j][i]=V[i][j];
			Ortho_V[j][i]=V[i][j];
		}
	}
	for(j=0;j<3;j++){
		if(j==0){
			for(i=0;i<3;i++){
			Ortho_V[j][i]=V[i][j];
			}
		}else{
			for(i=0;i<j;i++){
			kv[i]= vec_multiply(Ortho_V[i],V_T[j],3)/vec_multiply(Ortho_V[i],Ortho_V[i],3) ;//a_i * b_i/b_i^2
			for(k=0;k<3;k++){
				Ortho_V[j][k]=Ortho_V[j][k]-kv[i]*Ortho_V[i][k];
			}
		}
		}
		
	}
	for(i=0;i<3;i++){
		for(j=0;j<3;j++){
		V[i][j]=Ortho_V[j][i];
		}
	}
	printf("�������õ���V�������£�\n");
	for(i=0;i<4;i++){
		printf("");
		for(j=0;j<4;j++){
			printf("%f\t",V[i][j]);
		}
		printf("\n");
	}
	printf("V^T����Ϊ��\n");
	for(i=0;i<4;i++){
		printf("");
		for(j=0;j<4;j++){
			printf("%f\t",V[j][i]);
		}
		printf("\n");
	}
//	for(k=0;k<3;k++){
//		for(i=0;i<4;i++){
//			record[i][i]=record_s[i][i]-lambda[k];
//	}
//	printf("AA^T-lambad_%dIΪ��\n",k+1);
//	for(i=0; i<4; i++) {
//		for(j=0; j<4; j++) {
//			printf("%f,",record[i][j]);
//		}
//		printf("\n");
//	}
//	}
	system("pause");
	return 0;
}
