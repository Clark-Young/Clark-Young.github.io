#include<stdio.h>
#include<stdlib.h>
#include<math.h>

double sum_ainj(double a[][4],int dimension) {
	int i,j;
	double sum_sumainj=0;
	for(i=0; i<dimension; i++) {
		for(j=0; j<dimension; j++) {
			if(j!=i) {
				sum_sumainj+=a[i][j]*a[i][j];
			}
		}
	}
	return sqrt(sum_sumainj);
}
double vec_multiply(double a[],double b[],int c){
	int i=0;
	double sum=0;
	for(i=0;i<c;i++){
		sum+=a[i]*b[i];
	}
	return sum;
}

void Bubble_sort(double arr[], double V[4][4], int size) {
	int j,i,k;
	double tem;
	for (i = 0; i < size-1; i ++) {
		int count = 0;
		for (j = 0; j < size-1 - i; j++) {
			if (arr[j] < arr[j+1]) {
				tem = arr[j];
				arr[j] = arr[j+1];
				arr[j+1] = tem;
				count = 1;
				for(k=0;k<4;k++){
					tem=V[k][j];
					V[k][j]=V[k][j+1];
					V[k][j+1]=tem;
				}
			}
		}
		if (count == 0)
			break;
	}

}

double solve_rb(double a) {
	double t_1=0,t_2=0;
	t_1=-a+sqrt(a*a+1);
	t_2=-a-sqrt(a*a+1);
	if(fabs(t_1)>fabs(t_2)) {
		return t_2;
	} else {
		return t_1;
	}
}

void svd(double X[4][4],double lambda[4],double U[4][4]){
	int count =0;
	double ast;
	double a,b;
	double s=0;
	long double t;
	double c,d;
	int i,j,k,p=0,q=1;
	double temp;
	double copy_U[4][4];
	double Q[4][4],copy_Q[4][4];
	double copy[4][4];
	for(i=0; i<4; i++) { // ���󸳳�ֵ
		for(j=0; j<4; j++) {
			U[i][j]=0;
			Q[i][j]=0;
		}
	}
	for(i=0; i<4; i++) {
		U[i][i]=1;
		Q[i][i]=1;
	}
	printf("����õ���1/mXX^TΪ��\n");
	for(i=0; i<4; i++) {
		for(j=0; j<4; j++) {
			printf("%f,",X[i][j]);
		}
		printf("\n");
	}
	while(sum_ainj(X,4)>0.000000001) {
		count=count+1;
		temp=X[0][1];
		p=0;
		q=1;
		for(i=0; i<4; i++) {
			for(j=i+1; j<4; j++) {
				if(i!=j) {
					if(fabs(X[i][j])>fabs(temp)) {
						p=i;
						q=j;
						temp=X[i][j];
					}
				}
			}
		}

		s=(X[q][q]-X[p][p])/(2*X[p][q]);

		if(s==0) {
			t=1;
		} else {
			t=solve_rb(s);
		}

		c=1/sqrt(1+t*t);
		d=t/sqrt(1+t*t);
		for(i=0; i<4; i++) {
			for(j=0; j<4; j++) {
				copy[i][j]=X[i][j];
				copy_U[i][j]=U[i][j];
			}
		}
		Q[p][p]=c,Q[p][q]=d,Q[q][p]=-d,Q[p][p]=c;
		for(i=0; i<4; i++) {
			for(j=0; j<4; j++) {
				U[i][j]=0;
			}
		}
		for(i=0; i<4; i++) {
			for(j=0; j<4; j++) {
				for(k=0; k<4; k++) {
					U[i][j]=U[i][j]+copy_U[i][k]*Q[k][j];
				}
			}
		}
		for(i=0; i<4; i++) {
			for(j=0; j<4; j++) {
				if(i==j) {
					Q[i][j]=1;
				} else {
					Q[i][j]=0;
				}
			}
		}
		for(i=0; i<4; i++) {
			if(i!=p&&i!=q) {
				X[i][p]=X[p][i]=c*copy[p][i]-d*copy[q][i];
				X[i][q]=X[q][i]=c*copy[q][i]+d*copy[p][i];
			}
		}
		X[p][p]=copy[p][p]-t*copy[p][q];
		X[q][q]=copy[q][q]+t*copy[p][q];
		X[p][q]=X[q][p]=0;
		ast=sum_ainj(X,4);
		if(count>=54) {
			break;
		}
	}
	for(i=0; i<4; i++) {
		if(fabs(X[i][i]>0.000000000001)){
			lambda[i]=X[i][i];
		}else{
			lambda[i]=0;
		}
	}
	Bubble_sort(lambda,U,4);
}

int main(){
    double Data[150][5];
    double M[4][4]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
    double average[5];
    double X[5][150];
    int i=0,j=0,k=0;
    double sum=0;
    double lambda[4];
    double U[4][4];
    double Y[3][150];
    double X_2[2][4];
    FILE *fp=NULL;
    FILE *fp2=NULL;
    fp=fopen("iris.txt","r");
    fp2=fopen("output.txt","w+");
    for(i=0;i<150;i++){
        fscanf(fp,"%lf,%lf,%lf,%lf,%lf\n",&Data[i][0],&Data[i][1],&Data[i][2],&Data[i][3],&Data[i][4]);
    }
    for(i=0;i<4;i++){
        sum=0;
        for(j=0;j<150;j++){
            sum+=Data[j][i];
        }
        average[i]=sum/150;
        // printf("%f\t",average[i]);
    }
    average[4]=0;
    for(i=0;i<150;i++){
        Y[2][i]=Data[i][4];
    }
    for(i=0;i<150;i++){
        for(j=0;j<5;j++){
            X[j][i]=Data[i][j]-average[j];
        }
    }
    for(i=0;i<4;i++){
        for(j=0;j<4;j++){
            for(k=0;k<150;k++){
                M[i][j]=M[i][j]+X[i][k]*X[j][k];
            }
            M[i][j]=M[i][j]/4;
            // printf("%f,",M[i][j]);
        }
        // printf("\n");
    }
    svd(M,lambda,U);
    	printf("����ֵΪ��");	
	for(i=0; i<4; i++) {
		printf("%.16f\t",lambda[i]);

	}
	printf("\n");	
	printf("��֮��Ӧ����������Ϊ��\n");	
	for(i=0; i<4; i++) {
		for(j=0; j<4; j++) {
			printf("%f\t",U[i][j]);
		}
		printf("\n");
	}
	printf("\n");
    // ������������ lambda �� U��������ֻҪ��ȡ Y�Ϳ���
    for(i=0;i<2;i++){
        for(j=0;j<4;j++){
            X_2[i][j]=U[j][i];
            // printf("%f,",X_2[i][j]);
        }
        // printf("\n");
    }
    for(i=0;i<150;i++){
        for(j=0;j<2;j++){
            Y[j][i]=0;
        }
    }
    for(i=0;i<2;i++){
        for(j=0;j<150;j++){
            for(k=0;k<4;k++){
                Y[i][j]=Y[i][j]+X_2[i][k]*X[k][j];
            }
        }
    }
    for(j=0;j<150;j++){
            fprintf(fp2,"{%f,%f},",Y[0][j],Y[1][j]);
			if((j+1)%50==0){
				fprintf(fp2,"\n");
			}
    }
    system("pause");
    return 0;
}