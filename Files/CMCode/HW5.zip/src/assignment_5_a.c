#include<stdio.h>
#include<stdlib.h>
#include<math.h>

int main(){
    double x[21]={0},y[21]={0};
    int i=0,j=0;
    double Ma[19][19]={0};
    double v[20]={0},u[20]={0};
    double h[20]={0};
    double lambda[20]={0},mu[20]={0};
    double mu_c[20]={0};
    double d[20]={0};
    double M[21]={0};
    double inter[20]={0};
    double S_3[20],S_2[20],S_1[20],S_0[20];
    FILE *data=NULL;
    data=fopen("point.txt","r");
    for(i=0;i<21;i++){
        fscanf(data,"%lf %lf\n",&x[i],&y[i]); 
    }
    for(i=0;i<20;i++){
        h[i]=x[i+1]-x[i]; 
    }

    for(i=1;i<20;i++){
        lambda[i]=h[i]/(h[i]+h[i-1]); 
        mu[i]=1-lambda[i];
        d[i]=3*(y[i+1]-2*y[i]+y[i-1]);
    }
    for(i=1;i<20;i++){
        mu_c[i]=mu[i];
    }
    mu_c[1]=0;
    for(i=1;i<20;i++){
        u[i]=2-mu_c[i]*v[i-1];
        v[i]=lambda[i]/u[i];
    }
    for(i=1;i<20;i++){
        inter[i]=(d[i]-mu_c[i]*inter[i-1])/u[i];
    }
    v[19]=0;
    for(i=19;i>0;i--){
        M[i]=inter[i]-v[i]*M[i+1];
    }
    M[0]=0,M[20]=0;

    printf("����õ���������������S(x)=\n");
    for(i=0;i<20;i++){
        S_3[i]=(-M[i]+M[i+1])/(h[i]*6);
        S_2[i]=-(-M[i]*x[i+1]+M[i+1]*x[i])/(h[i]*2);
        S_1[i]=(-M[i]*x[i+1]*x[i+1]+M[i+1]*x[i]*x[i])/(h[i]*2)+(y[i+1]-y[i])/h[i]-h[i]*(M[i+1]-M[i])/6;
        S_0[i]=-(-M[i]*x[i+1]*x[i+1]*x[i+1]+M[i+1]*x[i]*x[i]*x[i])/(h[i]*6)+(x[i+1]*y[i]-x[i]*y[i+1])/h[i]-h[i]*(x[i+1]*M[i]-x[i]*M[i+1])/6;
        printf("%fx^3+%fx^2+%fx+%f,%f<=x<=%f,\n",S_3[i],S_2[i],S_1[i],S_0[i],x[i],x[i+1]);
    }
    system("pause");
    return 0;
}