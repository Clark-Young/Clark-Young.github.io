#include<stdio.h>
#include<math.h>

double distance(double a[], double b[],int i) {//���������Ķ����� 
	int j;
	double sum=0;

	for(j=0; j<i; j++) {
		sum=sum+(a[j]-b[j])*(a[j]-b[j]);
	}
	return sqrt(sum);
}

double sym_function(double a, double varepsilon, double x) {
	double value;
	value=(1-a)/(1-exp(-1/varepsilon))*(1-exp(-x/varepsilon))+a*x;
	return value;
}

int main() {
	double x=0;
	double A[99][99];
	double b[99],y[99],former_y[99];
	double exact_value[100];
	int i=0,method;
	int n;
	double y_1[99];
	double ratio,varepsilon,a;
	double astringency;
	double rank,temp,temp_sum=0;
	int j,k,l,m,t,s,d;
	printf("������n��varepsilon��a\n");
	scanf("%d %lf %lf",&n,&varepsilon,&a);
	double h;
	h=1.0/n;
	{
		for(i=0; i<n-1; i++) {
			for(j=0; j<n-1; j++) {
				A[i][j]=0;
			}
		}
		for(i=0; i<n-1; i++) {
			A[i][i]=-(2*varepsilon+h);
			b[i]=a*h*h;
			y[i]=1;
			former_y[i]=0;
		}
		b[n-2]=b[n-2]-(varepsilon+h);
		for(i=1; i<n-1; i++) {
			A[i][i-1]=varepsilon;
			A[i-1][i]=varepsilon+h;
		}
		for(j=0; j<n-1; j++) {
			rank=A[j][j];
			t=j;
			for(k=j+1; k<n-1; k++) {
				if(fabs(A[k][j])>fabs(rank)) {
					rank=A[k][j];
					t=k;
				}
			}
			if(t!=j) {
				for(l=j; l<n-1; l++) {
					temp=A[j][l];
					A[j][l]=A[t][l];
					A[t][l]=temp;
				}
				temp=b[t];
				b[t]=b[j];
				b[j]=temp;
			}
			for(m=j+1; m<n-1; m++) {
				ratio=A[m][j]/A[j][j];
				b[m]=b[m]-ratio*b[j];
				for(l=j; l<n-1; l++) {
					A[m][l]=A[m][l]-ratio*A[j][l];
				}
			}
		}
		for(k=n-2; k>=0; k--) {
			for(l=k-1; l>=0; l--) {
				b[l]=b[l]-A[l][k]/A[k][k]*b[k];
			}
		}
		for(k=0; k<n-1; k++) {
			b[k]=b[k]/A[k][k];
			y_1[k]=b[k];
		}
	}

	{
		for(i=0; i<n-1; i++) {
			for(j=0; j<n-1; j++) {
				A[i][j]=0;
			}
		}
		for(i=0; i<n-1; i++) {
			A[i][i]=-(2*varepsilon+h);
			b[i]=a*h*h;
			y[i]=1;
			former_y[i]=0;
		}
		b[n-2]=b[n-2]-(varepsilon+h);
		for(i=1; i<n-1; i++) {
			A[i][i-1]=varepsilon;
			A[i-1][i]=varepsilon+h;
		}
		astringency=distance(y,former_y,n-1);
		while(astringency>0.0000001) {
			for(i=0; i<n-1; i++) {
				former_y[i]=y[i];
			}
			for(i=0; i<n-1; i++) {
				for(k=0; k<n-1; k++) {
					if(k!=i) {
						temp_sum=temp_sum+A[i][k]*y[k];
					}
				}
				y[i]=(b[i]-temp_sum)/A[i][i];
				temp_sum=0;
			}
			astringency =distance(y,former_y,n-1);
		}

	}
	for(i=1; i<n; i++) {
		x=i*((double)1/n);
		exact_value[i]=sym_function(a,varepsilon,x);
	}
	FILE *fp = NULL;
    fp = fopen("result.txt", "w+");
    fprintf(fp,"����ֵ\t����Ԫ��������\tGauss-Seidel��Ԫ��������\n") ;
    for(i=0;i<99;i++){
    	fprintf(fp, "%f\t%f\t%f\n",exact_value[i+1],y_1[i],y[i]);
	}
	return 0;

}
